package com.example.android11lesson3dz;

public class CatModel {
    private String imageCat;
    private String description;
}
